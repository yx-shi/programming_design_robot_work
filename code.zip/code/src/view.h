#include<iostream>
#include "actuator.h"
#include "level.h"
#include"robot.h"
using namespace std;

void initialize_view(const LevelManager& level_manager) {
    //TODO：显示开始页面
}

void show_one_step(const Robot& robot) {
    //TODO: 执行单步后，显示当前界面
}

void show_final_result(const Robot& robot, const RunResult& result) {
    //TODO: 显示最终结果界面
}