#pragma once
#include <string>

const std::string local_level_path="../local_levels/"; //本地关卡存储路径
const std::string test_path="../test_input/"; //资源文件路径